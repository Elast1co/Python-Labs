user = input ("Enter your name :")
auth_user = ["Reda" , "Mohamed" , "Dave"]

if user in auth_user :
    print (f"Weclome to the server,{user}")
else:
    print ("Access Denied")