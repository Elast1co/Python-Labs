# using isalpha to check if its one word or not1
user_input = input ("Enter your name :")

if user_input.isalpha():
    print (f"Weclome {user_input}")
else :
    print ("Wrong type , Please enter your name")