# using isalpha to check if its one word or not1
user_input = input ("Enter your name :")

if user_input.isalpha():
    print ("Valid name entered:")
else :
    print ("Invalid input , please use alphaptic chaarchters only.")

print ("======================================")