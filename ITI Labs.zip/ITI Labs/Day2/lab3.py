#Example with a list 
fruits = ["apples","banana","cherry"]
print ("banana" in fruits)
print ("grapes" in fruits)
if "banana" in fruits:
    print ("Theres food for the monkeys")
else :
    print ("Theres no food for the monkeys")