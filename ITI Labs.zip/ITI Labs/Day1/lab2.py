x ="jfhvoi"
for i in range (len(x)):
    if x[i] == "i":
        print(i)