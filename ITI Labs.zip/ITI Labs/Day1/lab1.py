vowles = "aeiouAEIOU"
i = input ("Enter your string:")
count = 0
for j in i :
    if j in vowles :
        count +=1
print ("The count is ",count)
